//import conversation from './conversationModel.js'

import {
    io
} from '../../index.js';
import conversationActions from './conversationMethods.js';
import { informOperator } from '../../utils/informOperator.js';
const conversationDb = new conversationActions
import logger from '../../config/newLogger.js'
import * as info from '../../data.js'
import {socketIds} from '../connection/connectionEvents.js'
import { getCnvById, getConv, searchConversationMessages } from '../../services/conversationsRequests.js';
import { getAgent, getAgentDetails } from '../../services/userRequests.js';
const currentDate = new Date();
import messagesActions from "../messages/messageMethods.js";
import { filterForms } from '../../utils/forms.js';
const messageDb = new messagesActions();
const fullDate = currentDate.toLocaleString();

const ioConversationEvents = function () {

    //room namespace
    io.on('connection', async (socket) => {

        // Create a new room
        // onConversationStart : Fired when the conversation created.
        socket.on('onConversationStart', (data) => {
            try {
                if(data){
                    conversationDb.addCnv(data).then(async (res) => {                       
                        // Find the socket IDs corresponding to the members
                        const socketIdsToNotify = Object.entries(socketIds).map(([socketId,user])=>
                        (res.members?.includes(user.userId)||(user.accountId==res.owner_id && user.role==="ADMIN")) ? socketId : null ).filter(item=>item)
                        socket.join(res._id.toString())
                        // Send the "joinMember" event to the  socket IDs
                        socketIdsToNotify.forEach((socketIdObj) => {
                          socket.to(socketIdObj.socketId).emit("joinConversationMember",res);
                        });
                        socket.emit("onConversationStarted",res);

                        const conversationData = await conversationDb.getCnv(res._id.toString());
                        if (conversationData.status == 0) {
                          let eventName="onConversationStarted"
                          let eventData= [res]
                          try{
                            informOperator(io,socket.id,conversationData,eventName,eventData);
                          }catch(err){
                            console.log("informOperator err",err)
                            throw err;
                          }
                        }

                      });
                      logger.info(`Event: onConversationStart ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token taw nzidouha , date: ${fullDate}"   \n `)
                    }
            } catch (err) {
                logger.error(`Event: onConversationStart ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :taw nzidouha ,error ${err}, date: ${fullDate}    \n `)
            }
        });

        socket.on('joinRoom', (data) => {
            try {
                socket.join(data)
                socket.emit('roomJoined', data)
            } catch (err) {
                logger.error(`Event: onCreate roo ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :taw nzidouha ,error ${err}, date: ${fullDate}    \n `)
            }
        })


        // onConversationEnd : Fired when the conversation ended.
        socket.on('onConversationEnd', (data) => {
            try {
          
                logger.info(`Event: onConversationEnd ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :"taw nzidouha , date: ${fullDate}"   \n `)
                socket.emit("onConversationEnd", data)
            } catch (err) {
                logger.error(`Event: onConversationEnd ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :"taw nzidouha ,error ${err}, date: ${fullDate} "   \n `)
            }
        });
        // onConversationUpdated : Fired when the conversation data updated.
        socket.on('updateConversationLM', async (id, message, from) => {
            try {
                await conversationDb.getCnvById(id).then(async (res) => {
                    if (res.owner_id === id) {
                    }
                    await conversationDb.putCnvLM(id, message)
                    socket.emit("onConversationUpdated", id, message)
                })
                logger.info(`Event: onConversationUpdated ,data: ${JSON.stringify(id,message)} , socket_id : ${socket.id} ,token :"taw nzidouha , date: ${fullDate}"   \n `)
            } catch (err) {
                logger.error(`Event: onConversationUpdated ,data: ${JSON.stringify(id,message)} , socket_id : ${socket.id} ,token :"taw nzidouha ,error:${err} , date: ${fullDate}"   \n `)
            }
        });

        // onConversationDeleted : Fired when the conversation deleted.

        socket.on('onConversationDeleted', (data) => {
            try {
                logger.info(`Event: onConversationDeleted ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :"taw nzidouha , date: ${fullDate}"   \n `)
                conversationDb.deleteCnv(data.metaData).then((res) => {
                    socket.emit("onConversationDeleted", res)
                })
            } catch (err) {
                logger.error(`Event: onConversationDeleted ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :"taw nzidouha ,error:${err} , date: ${fullDate}"   \n `)
            }
        });

        // onConversationSearch : Search for messages containing a specific term.

        socket.on('onConversationSearch', async (conversationId, term,messageId) => {
            try {
                // logger.info(`Event: onConversationDeleted ,data: ${JSON.stringify(data)} , socket_id : ${socket.id} ,token :"taw nzidouha , date: ${fullDate}"   \n `)
                const user = socketIds[socket.id];
                socket.emit("onConversationSearchResult", await searchConversationMessages(conversationId, term, user,messageId))
            } catch (err) {
                 console.log("error",err)
                socket.emit("onConversationSearchFailed",err.toString())
            }
        });


        socket.on('checkConversation',async(data)=>{
            const conversationFirst = await getConv(data)
            const agentDetails=await getAgentDetails(data.agentId)
            if(conversationFirst.data){
                socket.emit('checkConversation',conversationFirst.data.conversation[0]._id.toString(),agentDetails.id,agentDetails.full_name)
            }else {
                //create conversation and send form 
          const conversationDetails = await conversationDb.addCnv({
            app: data.accountId,
            user: data.agentId,
            action: "conversation.create",
            metaData: {
              name: agentDetails.full_name,
              channel_url: "",
              conversation_type: "1",
              description: "private chat",
              owner_id: data.accountId,
              members: [data.userId, data.agentId],
              permissions: [],
              members_count: 2,
              status: agentDetails.is_active === true ? "1" :"0",
              max_length_message: "256",
            },
          });


          let agentStatus;
          agentDetails.is_active===true  ? agentStatus=1 :agentStatus=2

            //send conversationStatusUpdated to agent agentDetails.socket_id
            if(agentDetails.is_active){
              const conversationData = await getCnvById(
                conversationDetails._id.toString()
              );

             io.to(agentDetails.socket_id).emit('conversationStatusUpdated',conversationData,1)
             socket.join(conversationDetails._id.toString())
            }
        
          
          if(conversationDetails){
            socket.emit('checkConversation',conversationDetails._id.toString(),agentDetails.id,agentDetails.full_name)

              const formMsg = filterForms(
                "2",
                data.accountId,
                data?.gocc_contact_id ? "gocc" : null,
                agentStatus 
              );
              
              if (formMsg) {
                formMsg.status = 0;
                //add message to data base and emit to the client
                messageDb
                  .addMsg({
                    app: data.accountId,
                    user: agentDetails._id.toString(),
                    action: "message.create",
                    from: agentDetails._id.toString(),
                    metaData: {
                      type: "form",
                      conversation_id: conversationDetails._id,
                      user: agentDetails._id.toString(),
                      message: JSON.stringify(formMsg),
                      data: "non other data",
                      origin: "web",
                    },
                    to: data.userId,
                  })
                  .then(async (savedMsg) => {
                  
        
                    socket.emit("onMessageReceived", {
                      messageData: {
                        content: savedMsg.message,
                        id: savedMsg._id,
                        from: agentDetails._id.toString(),
                        conversation: conversationDetails._id,
                        date: savedMsg.created_at,
                        uuid: savedMsg.uuid,
                        type: "form",
                      },
                      newConversation: conversationDetails._id,
                      isSender: false,
                      direction: "out",
                      userId: data.user,
                      senderName: agentDetails.full_name,
                      contactAgentId:agentDetails.id,
                      status:conversationDetails.status
                    });
                    if (conversationDetails.status == 0) {
                      let eventName = "onMessageReceived";
                      let eventData = [
                        {
                          messageData: {
                            content: savedMsg.message,
                            id: savedMsg._id,
                            from: agentDetails._id.toString(),
                            conversation: conversationDetails._id,
                            date: savedMsg.created_at,
                            uuid: savedMsg.uuid,
                            type: "form",
                          },
                          newConversation: conversationDetails._id,
                          isSender: false,
                          direction: "out",
                          userId: data.user,
                          senderName: agentDetails.full_name,
                        },
                      ];
                      try {
                        informOperator(
                          io,
                          socket.id,
                          conversationDetails,
                          eventName,
                          eventData
                        );
                      } catch (err) {
                        console.log("informOperator err", err);
                        throw err;
                      }
                    }
            

                  });


              }
            
        
            }
  

            }
           


            
        })
    });
}


export default ioConversationEvents