import {
    io
} from '../../index.js'


let numUsers=0
const ioAppEvents = function () {

    io.on("connection", (socket) => {   
       
   })
}
export default ioAppEvents