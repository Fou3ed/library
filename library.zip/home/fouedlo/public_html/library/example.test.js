import { GetMessages } from './services/messageRequests';
test('exampleFunction should return "Hello, World!"', () => {
    expect(GetMessages()).toBe('Hello, World!');
});