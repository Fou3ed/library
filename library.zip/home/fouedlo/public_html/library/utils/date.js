

export const date = async function (data) {
   
    return fullDate
}
