import axios from "axios";
import { postMessage, putMessage } from "../services/messageRequests.js";
import { socketIds } from "../models/connection/connectionEvents.js";
import addLogs from "./addLogs.js";
import { getCnvById } from "../services/conversationsRequests.js";
import { putUser } from "../services/userRequests.js";
import sendEmail from "./nodeMailer.js"
import {informOperator }from "./informOperator.js"
import sendTextCapture from "./sendTextCapture.js"
import {
  io
} from '../index.js'
const saveFormData = async (dataForm,socket) => {
    let data = JSON.parse(dataForm);
try{
    axios.post(`${process.env.API_PATH}/addcontactforms`, dataForm, {
        headers: {
            'Content-Type': 'application/json',
             "key": `${process.env.API_KEY}` 
        }
    })
        .then(async response => {
try {
  let receiverEmail = null;
  if (data.forms && Array.isArray(data.forms)) {
    for (const form of data.forms) {
      if (form.fieldId === "4" && form.value) { 
        receiverEmail = form.value;
        break;
      }
    }
  }
  if (receiverEmail) {
    const userName = data.forms.find(item => item.fieldId === "1")?.value;
      sendEmail(receiverEmail,JSON.stringify(response.data.data),userName,data.language)
  }
} catch (error) {
  console.error("Error parsing JSON:", error);
}
         putMessage(data.messageId,data.form,false)
            //add, logs
            const user=socketIds[socket.id]
            const messageData=await  postMessage({
                app: user.accountId,
                user: user.userId,
                action: "message.create",
                metaData: {
                  type: "log",
                  conversation_id:data.conversationId, 
                  user: user.userId,
                  message: JSON.stringify({
                    "messageId":data.messageId,
                    "user_id":user.userId,
                    "action": "end form",
                    "element": "21",
                    "element_id": data.form.form_id,
                    "log_date": new Date(),
                    "source": "2",
                }    ),
                  origin: "web",
                },
              })

            socket.to(data.conversationId).emit('onMessageReceived', {
              messageData,
              newConversation: data.conversationId,
              userId: user.userId,  
            });
          
            addLogs({
                action: "end form",
                element: "21",
                element_id: data.form.form_id,
                source : 2,
                user_id:user.contactId,
              })
              

                  //update user information 
                 const userDetails =await putUser(user.userId,data.form)
                 socket.emit("formSaved",true,userDetails,dataForm)
                 socket.to(data.conversationId).emit('userUpdated',userDetails)
                 socket.to(data.conversationId).emit("formSaved",true,dataForm)  
                  const conversationData = await getCnvById(data.conversationId);
                   //for the client : receive message , for the agent : sent message of the text_capture of the form                 
                
                  const differentIdMember = conversationData.member_details.find(member => member._id.toString() !== user.userId);
                  if(data?.form?.message_capture){
                    socket.join(data.conversationId)

                    sendTextCapture(user,differentIdMember,conversationData,data.form.message_capture,data.form.form_type)
                  }

                  //add message fl bdd messageBloc 
                  //send receiveMessage

              if (conversationData.status == 0) {
                let eventName="formSaved"
                try{
                  informOperator(io,socket.id,conversationData,eventName,dataForm);
                  informOperator(io,socket.id,conversationData,"userUpdated",userDetails);
                }catch(err){
                  console.log("informOperator err",err)
                  throw err;
                }
              }
        })
        .catch(error => {
            console.log("error saving form",error)
            socket.emit("formSaved",false,dataForm)
        });
    
}catch(err){
    console.log("error saving form in iheb's data base",err)
}
 
}

export default saveFormData;

